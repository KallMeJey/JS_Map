# Comment installer/utiliser ce repo?

Après avoir cloner ce repository sur votre pc, ouvrer une fenetre cmd dans ce dossier et faite des `cd` pour etre dans le dossier Serveur ou le dossier client.
Ensuite, éxecutez la commande `npm install` pour installer toutes les dépendances automatiquement. Il faut avoir installer node.js au préalable pour que ça fonctionne bien sur.

# Lancer le serveur

Pour lancer le serveur il suffit de se positionner dans le dossier Serveur dans un fenetre cmd et d'entrer `npm start`
Le serveur doit se lancer sur le port 3000 normalement.
